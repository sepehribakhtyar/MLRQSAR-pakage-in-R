# This program has been written by Dr. Bakhtyar Sepehri.
# this function calculates Variance Inflation Factor (VIF) between descriptors that is a criteria of multi-collinearity between descriptors. If there is no corellation between a descriptor with others, VIF is 1 and maximum acceptable VIF is 10.
# Xtrain is desciptor matrix for train set.
# In Xtrain, descriptors are in columns and molecules are in rowes.
# source code and type following commend in Console:
# VIF(Xtrain)
VIF=function(Xtrain){Dim_Xtrain=as.matrix(dim(Xtrain))
RXmatpred=matrix(0,Dim_Xtrain[1],Dim_Xtrain[2])
RXmatpredbar=(matrix(0,Dim_Xtrain[1],Dim_Xtrain[2]))
R2=matrix(0,1,Dim_Xtrain[2])
VIF=matrix(0,1,Dim_Xtrain[2])
for (i in 1:Dim_Xtrain[2]) {X=Xtrain
RX=X[,i]
X=X[,-i]
X=cbind(as.matrix(rep(1,Dim_Xtrain[1])),X)
b=solve(t(X)%*%X)%*%t(X)%*%RX
RXmatpred[,i]=X%*%b
RXmatpredbar[,i]=matrix(1,Dim_Xtrain[1])*mean(RXmatpred[,i])
} 
for (i in 1:Dim_Xtrain[2]) {W=Xtrain[,i]-RXmatpredbar[,i]
SST=t(W)%*%W
A=RXmatpred[,i]-RXmatpredbar[,i]
SSR=t(A)%*%A
R2[i]=SSR/SST
VIF[i]=1/(1-R2[i])
}
Output_list=list(VIF=VIF)
return(Output_list)
}