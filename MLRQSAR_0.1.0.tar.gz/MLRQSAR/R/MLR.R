# This program builds Multiple Linear Regression (MLR).
# This program has been written by Dr. Bakhtyar Sepehri.
# Program has been written based on following refernces:
# Daryl S. Paulson, Handbook of regression and modeling : applications for the clinical and
# pharmaceutical industries,  Taylor & Francis Group, LLC, 2007.
# Applied Linear Regression, Wiley series in probability and statistics,2005.
# objects(molecules) must be in rows.
# m is the number of objects and n is the number of variables in Xtrain.
# In Xtrain and Xtest matrices,molecules are in rows and descriptors are in columns.
# Xtrain is desciptor matrix for training set and Xtest is desciptor matrix for test set.
# Ytrain is activity vector (a column vector) for training set and Ytest is activity vector (a column vctor) for test set.
# source code and type following commend in Console:
# MLR(Xtrain, Xtest, Ytrain, Ytest)
MLR=function(Xtrain, Xtest, Ytrain, Ytest){Dim_Xtrain=dim(Xtrain)
  Dim_Xtrain=as.matrix(Dim_Xtrain)
  N_rowes_train=Dim_Xtrain[1]
  N_columns_train=Dim_Xtrain[2]
  Ones_train=matrix(1,N_rowes_train,1)
  Xtrain_new=cbind(Ones_train,Xtrain)
  b=solve(t(Xtrain_new)%*%Xtrain_new)%*%t(Xtrain_new)%*%Ytrain
  N_rowes_test=length(Ytest)
  Ones_test=matrix(1,N_rowes_test,1)
  Xtest_new=cbind(Ones_test,Xtest)
  Ytrain_pred=Xtrain_new%*%b
  Ytest_pred=Xtest_new%*%b
  Ytrain_bar=mean(Ytrain)*Ones_train
  w=Ytrain-Ytrain_bar
  SST_train=t(w)%*%w
  A=Ytrain_pred-Ytrain_bar
  SSR_train=t(A)%*%A
  SSEtrain=SST_train-SSR_train
  R2_train=SSR_train/SST_train
  Res_train=Ytrain-Ytrain_pred
  RMSE_train=sd(Res_train)
  F=((N_rowes_train-N_columns_train-1)*R2_train)/(N_columns_train*(1-R2_train))
  se=sqrt((sum((Ytrain-Ytrain_pred)^2))/(length(Ytrain)-length(b)))
  sb=se*sqrt(diag(solve(t(Xtrain_new)%*%Xtrain_new)))
  t=b/sb
  Res_test=Ytest-Ytest_pred
  RMSE_test=sd(Res_test)
  Ytest_bar=mean(Ytest)*Ones_test
  z=Ytest-Ytest_bar
  d=Ytest-Ytest_pred
  R2_test=1-((t(d)%*%d)/(t(z)%*%z))
  Output_list=list(R2_train=R2_train,RMSE_train=RMSE_train,b=b,sb=sb,t=t,F=F,R2_test=R2_test,RMSE_test=RMSE_test,Ytrain_pred=Ytrain_pred,Ytest_pred=Ytest_pred)
  return(Output_list)
}

