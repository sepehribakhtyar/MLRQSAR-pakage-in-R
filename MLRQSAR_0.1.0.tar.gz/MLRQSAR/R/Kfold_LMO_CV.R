# This function runs leave-many-out (LMO)cross validation test based on K-fold.
# This program has been written by Dr. Bakhtyar Sepehri.
# "repeats" is the number of iteartion.
# "NG" is the number of groups.
# "Ytrain" is dependent variable (activity) vector(a column vector).
# "Xtrain" is independent variable(molecular descriptors) matrix.
# In Xtrain matrice,molecules are in rows and descriptors are in columns.
# m is the number of molecules or samples.
# "average_R2traincv", "Min_R2traincv" and "Max_R2traincv", respectively, are the mean, minimum and maximum of obtained R2 for "repeat" time run of program.
# "average_RMSEtraincv" is the mean of obtained RMSE for "repeat" time run of program.
# source code and type following commend in Console:
# Kfold_LMO_CV(Xtrain, Ytrain,NG,repeats)
Kfold_LMO_CV=function(Xtrain, Ytrain,NG,repeats){All_R2_CV=matrix(rep(0),1,repeats)
All_RMSE_CV=matrix(rep(0),1,repeats)
m=length(Ytrain)
ones_train=matrix(1,m,1)
Ytest_cv_pred_all_samples=matrix(rep(0),m,1)
for(i in 1:repeats){index_train=matrix(sample(m),m,1)
Xtrain=Xtrain[index_train,]
Ytrain=Ytrain[index_train]
groups=1+(0:(m-1))%%NG
for(group in 1:NG){Train_NG=matrix(which(groups!=group))
Test_NG=matrix(which(groups==group))
Xtrain_cv=Xtrain[Train_NG,]
Ytrain_cv=Ytrain[Train_NG]
Xtest_cv=Xtrain[Test_NG,]
Ytest_cv=Ytrain[Test_NG]
LY_train=length(Ytrain_cv)
LY_test=length(Ytest_cv)
ones_LY_train=matrix(1,LY_train,1)
ones_LY_test=matrix(1,LY_test,1)
Xtrain_cv=cbind(ones_LY_train,Xtrain_cv)
b=solve(t(Xtrain_cv)%*%Xtrain_cv)%*%t(Xtrain_cv)%*%Ytrain_cv
Xtest_cv=cbind(ones_LY_test,Xtest_cv)
Ytest_cv_pred=Xtest_cv%*%b
Ytest_cv_pred_all_samples[Test_NG]=Ytest_cv_pred
}
residualstest=Ytrain-Ytest_cv_pred_all_samples
All_RMSE_CV[i]=sd(residualstest)
Ytrain_bar=mean(Ytrain)*ones_train
z=Ytrain-Ytrain_bar
d=Ytrain-Ytest_cv_pred_all_samples
All_R2_CV[i]=1-((t(d)%*%d)/(t(z)%*%z))
}
Average_R2train_cv=mean(All_R2_CV)
Average_RMSEtrain_cv=mean(All_RMSE_CV)
MAX_R2train_cv=max(All_R2_CV)
MIN_R2train_cv=min(All_R2_CV)
Output_list=list(Average_R2train_cv=Average_R2train_cv,Average_RMSEtrain_cv=Average_RMSEtrain_cv,MAX_R2train_cv=MAX_R2train_cv,MIN_R2train_cv=MIN_R2train_cv)
return(Output_list)
}
