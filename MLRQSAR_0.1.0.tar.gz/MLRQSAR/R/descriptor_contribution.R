# This program calculates the contribution of each descriptor in the building of model and has ben written by Dr. Bakhtyar Sepehri.
# Xtrain is descriptor matrix for train set. In this matrix, molecules or objects are in rows and independent variables or descriptors are in columns.
# Xtrain has m rows and n columns.
# YYtrain is a column vector containing the activity of molecules.
# This function has been written based on following refernce:
# F. Liu, Y. Liang, C. Caob, N. Zhoua, QSPR study of GC retention indices for saturated esters on seven
# stationary phases based on novel topological indices, Talanta 72 (2007)1307-1315.
# To run function first define Xtrain  and Ytrain and then
# source code and  type following commend in Console:
# descriptor_contribution(Xtrain,Ytrain)
descriptor_contribution=function(Xtrain,Ytrain){Dim_Xtrain=dim(Xtrain)
Dim_Xtrain=as.matrix(Dim_Xtrain)
N_rowes_train=Dim_Xtrain[1]
N_columns_train=Dim_Xtrain[2]
Ones_train=matrix(1,N_rowes_train,1)
Xtrain_new=cbind(Ones_train,Xtrain)
b=solve(t(Xtrain_new)%*%Xtrain_new)%*%t(Xtrain_new)%*%Ytrain
Ytrain_pred=Xtrain_new%*%b
Ytrain_bar=mean(Ytrain)*Ones_train
w=Ytrain-Ytrain_bar
SST_train=t(w)%*%w
A=Ytrain_pred-Ytrain_bar
SSR_train=t(A)%*%A
SSEtrain=SST_train-SSR_train
R2_train=SSR_train/SST_train
meandescriptors=t(matrix(apply(Xtrain,2,mean)))
relative_contribution=matrix(rep(0),1,N_columns_train)
fraction_contribution=matrix(rep(0),1,N_columns_train)
b=b[-1]
bnew=b
for (i in 1:N_columns_train){relative_contribution[i]=bnew[i]*meandescriptors[i]
relative_contribution[i]=abs(relative_contribution[i])
}
for (i in 1:N_columns_train){fraction_contribution[i]=((R2_train*relative_contribution[i])/(sum(relative_contribution)))*100
}
Output_list=list(fraction_contribution=fraction_contribution)
return(Output_list)
}
