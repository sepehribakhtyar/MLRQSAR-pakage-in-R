# This code has been written by Dr. Bakhtyar Sepehri to investigate the validation of QSAR models by calculating Q2F1, Q2F2, Q2F3 and Concordance Correlation Coefficient (CCC).
# For more study, please see following paper:
# P. Gramatica, A. Sangion, A Historical Excursus on the Statistical Validation Parameters for QSAR Models: A Clarification Concerning Metrics and Terminology, J. Chem. Inf. Model. 56(2016)1127-1131.
# In this code:
# Ytrain is vector of dependent variable values for training set;
# Ytrain_pred is vector of predicted dependent variable values by created model for training set;
# Ytest is vector of dependent variable values for test set;
# Ytest_pred is vector of predicted dependent variable values by created model for test set;
# source code and type following commend in Console:
# General_validation(Ytrain, Ytrain_pred, Ytest, Ytest_pred)
General_validation=function(Ytrain, Ytrain_pred, Ytest, Ytest_pred){
m=length(Ytrain)
z=length(Ytest)
Q2F1=1-(sum((Ytest_pred-Ytest)^2)/(sum((Ytest-(mean(Ytrain_pred)*matrix(1,z)))^2)))
Q2F2=1-(sum((Ytest_pred-Ytest)^2)/(sum((Ytest-(mean(Ytest_pred)*matrix(1,z)))^2)))
Q2F3=1-((sum((Ytest_pred-Ytest)^2)/z)/((sum((Ytrain-(mean(Ytrain_pred)*matrix(1,m)))^2)/m)))
Output_list=list(Q2F1=Q2F1,Q2F2=Q2F2,Q2F3=Q2F3)
return(Output_list)}






