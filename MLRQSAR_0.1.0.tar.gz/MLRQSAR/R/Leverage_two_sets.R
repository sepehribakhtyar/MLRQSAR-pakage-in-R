# This function calculates the applicability domain of created model based
# on the calculation of leverage matrix for molecules.
# This program has been written by bakhtyar sepehri.
# Program has been written based on following refernces:
# Bakhtyar Sepehri, Raouf Ghavami, Design new P-glycoprotein modulators 
# based on molecular docking and CoMFA study of a, b-unsaturated 
# carbonyl-based compounds and oxime analogs as anticancer agents, Journal
# of Molecular Structure 1130 (2017) 922-928.
# In Xtrain and Xtest matrices,molecules are in rows and descriptors are in columns.
# Xtrain is desciptor matrix for training set and Xtest is desciptor matrix for test set.
# source code and type following commend in Console:
# Leverage_two_sets(Xtrain,Xtest)
Leverage_two_sets=function(Xtrain,Xtest){Dim_train=matrix(dim(Xtrain))
Leverage_critical=(3*(Dim_train[2]+1))/Dim_train[1]
X=rbind(Xtrain,Xtest)
H=X%*%solve(t(X)%*%X)%*%t(X)
Leverage=as.matrix(diag(H))
zz=length(Leverage)
Leverage_train=as.matrix(Leverage[1:Dim_train[1]])
Leverage_test=as.matrix(Leverage[(Dim_train[1]+1):zz])
Output_list=list(Leverage_critical=Leverage_critical,Leverage_train=Leverage_train,Leverage_test=Leverage_test)
return(Output_list)
}
