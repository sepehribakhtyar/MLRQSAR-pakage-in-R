# This program has been written by Dr. Bakhtyar Sepehri.
# This function runs leave-one-out (LOO) cross validation test.
# Ytrain is dependent variable vector (a column vector).
# Xtrain is independent variables (desciptors) matrix for train set.
# objects(molecules) must be in rows.
# m is the number of objects and n is the number of variables.
# In Xtrain matrix,molecules are in rows and descriptors are in columns.
# To run function first define Ytrain and Xtrain and then
# source code and type following commend in Console:
# LOOCVMLR(Xtrain,Ytrain)
LOOCVMLR=function(Xtrain,Ytrain){a=dim(Xtrain)
m=a[1]
n=a[2]
Ones_train=matrix(1,m,1)
Ones=matrix(rep(1),m-1,1)
Ytrain_pred_cv=matrix(rep(0),m,1)
for (i in 1:m) {Y=Ytrain
X=Xtrain
RY=t(matrix(Y[i,]))
RX=t(matrix(X[i,]))
Y=Y[-i,]
X=X[-i,]
X=cbind(Ones,X)
b=solve(t(X)%*%X)%*%t(X)%*%Y
RX=cbind(1,RX)
Ytrain_pred_cv[i]=RX%*%b
}
Ytrain_bar=mean(Ytrain)*Ones_train
w=Ytrain-Ytrain_bar
SST_train=t(w)%*%w
A=Ytrain_pred_cv-Ytrain_bar
SSR_train=t(A)%*%A
SSEtrain=SST_train-SSR_train
R2_train_CV=SSR_train/SST_train
Res_train=Ytrain-Ytrain_pred_cv
RMSE_CV=sd(Res_train)
Output_list=list(R2_train_CV=R2_train_CV,RMSE_CV=RMSE_CV)
return(Output_list)
}
