# This code has been written by Dr. Bakhtyar Sepehri to investigate the validation of QSAR models.
# For more study, please see following paper:
# P. Gramatica, A. Sangion, A Historical Excursus on the Statistical Validation Parameters for QSAR Models: A Clarification Concerning Metrics and Terminology, J. Chem. Inf. Model. 56(2016)1127-1131.
# Roya Ahmadi, Bakhtyar Sepehri & Raouf Ghavami (2019)  Journal of Receptors and Signal Transduction, 39:3, 264-275.
# In this code:
# Ytrain is the vector (column vector) of dependent variable values for training set;
# Ytrain_pred is the vector (column vector) of predicted dependent variable values by created model for training set;
# Ytest is the vector (column vector) of dependent variable values for test set;
# Ytest_pred is the vector (column vector) of predicted dependent variable values by created model for test set;
# to run code,first define Ytrain, Ytrain_pred, Ytest, Ytest_pred vectors and copy and past following argument in workspace:
# Validation_two_sets(Ytrain, Ytrain_pred, Ytest, Ytest_pred)
# Created model is acceptable if:
# Q2>0.5 and r2>0.6
# r2_relative<0.1
# 0.85<k and k_prim<1.15
# delta_r2_zero<0.3
# r2_m_mean>0.5
# delta_r2_m<0.2
#############################
# R2 is squared correlation coefficient and RMSE is root mean square error and MAE is mean absolute error.
# CCC2 is squared concordance correlation coefficient.
# k and k_prim are k and k', respectively.
# r2_zero and r_prim2_zero are squared r0 and squared r'0, respectively.
# r2_m, r_prim2_m, r2_m_mean_train and delta_r2_m are squared rm, squared r'm,mean r2m and ??r2m, respectively.
# r2_relative_1, r2_relative_2 and delta_r2_zero are parameters that calcylate based on r2,r2_zero and r_prim2_zero.
###############################################################################################################################
# source code and type following commend in Console:
# Validation_two_sets(Ytrain, Ytrain_pred, Ytest, Ytest_pred)
#############################################################################################
Validation_two_sets=function(Ytrain, Ytrain_pred, Ytest, Ytest_pred){m=length(Ytrain)
z=length(Ytest)
mean_Ytrain_vector=mean(Ytrain)*matrix(1,m)
mean_Ytest_vector=mean(Ytest)*matrix(1,z)
mean_Ytrain_pred_vector=mean(Ytrain_pred)*matrix(1,m)
mean_Ytest_pred_vector=mean(Ytest_pred)*matrix(1,z)
# Calculating statistical parameters for training set
r2_train=(sum((Ytrain-mean_Ytrain_vector)*(Ytrain_pred-mean_Ytrain_pred_vector)))^2/((sum((Ytrain-mean_Ytrain_vector)^2))*(sum((Ytrain_pred-mean_Ytrain_pred_vector)^2)));
residuales_train=Ytrain-Ytrain_pred
RMSE_train=sd(residuales_train)
k_train=(sum(Ytrain*Ytrain_pred))/(sum((Ytrain_pred)^2))
k_prim_train=(sum(Ytrain*Ytrain_pred))/(sum((Ytrain)^2))
r2_zero_train=1-(sum((Ytrain-(k_train*Ytrain_pred))^2))/(sum((Ytrain-mean_Ytrain_vector)^2))
r_prim2_zero_train=1-(sum((Ytrain_pred-(k_prim_train*Ytrain))^2))/(sum((Ytrain_pred-mean_Ytrain_vector)^2));
r2_m_train=r2_train*(1-sqrt(abs(r2_train-r2_zero_train)))
r_prim2_m_train=r2_train*(1-sqrt(abs(r2_train-r_prim2_zero_train)))
r2_m_mean_train=(r2_m_train+r_prim2_m_train)/2
delta_r2_m_train=abs(r2_m_train-r_prim2_m_train)
r2_relative_1_train=(r2_train-r2_zero_train)/r2_train
r2_relative_2_train=(r2_train-r_prim2_zero_train)/r2_train
delta_r2_zero_train=abs(r2_zero_train-r_prim2_zero_train)
MAE_train=(sum(Ytrain_pred-Ytrain)/length(Ytrain))
CCC2_train=((2*sum((Ytrain-mean_Ytrain_vector)*(Ytrain_pred-(mean_Ytrain_pred_vector))))/(sum((Ytrain-mean_Ytrain_vector)^2)+sum((Ytrain_pred-mean_Ytrain_pred_vector)^2)+m*((mean(Ytrain)-mean(Ytrain_pred))^2)))^2
# Calculating statistical parameters for test set
r2_test=((sum((Ytest-mean_Ytest_vector)*(Ytest_pred-mean_Ytest_pred_vector)))^2)/((sum((Ytest-mean_Ytest_vector)^2))*(sum((Ytest_pred-mean_Ytest_pred_vector)^2)))
residualestest=Ytest-Ytest_pred
RMSE_test=sd(residualestest)
k_test=(sum(Ytest*Ytest_pred))/(sum((Ytest_pred)^2))
k_prim_test=(sum(Ytest*Ytest_pred))/(sum((Ytest)^2))
r2_zero_test=1-(sum((Ytest-(k_test*Ytest_pred))^2))/(sum((Ytest-mean_Ytest_vector)^2))
r_prim2_zero_test=1-(sum((Ytest_pred-(k_prim_test*Ytest))^2))/(sum((Ytest_pred-mean_Ytest_vector)^2))
r2_m_test=r2_test*(1-sqrt(abs(r2_test-r2_zero_test)))
r_prim2_m_test=r2_test*(1-sqrt(abs(r2_test-r_prim2_zero_test)))
r2_m_mean_test=(r2_m_test+r_prim2_m_test)/2
delta_r2_m_test=abs(r2_m_test-r_prim2_m_test)
r2_relative_1_test=(r2_test-r2_zero_test)/r2_test
r2_relative_2_test=(r2_test-r_prim2_zero_test)/r2_test
delta_r2_zero_test=abs(r2_zero_test-r_prim2_zero_test)
MAE_test=(sum(Ytest_pred-Ytest)/length(Ytest))
CCC2_test=((2*sum((Ytest-mean_Ytest_vector)*(Ytest_pred-(mean_Ytest_pred_vector))))/(sum((Ytest-mean_Ytest_vector)^2)+sum((Ytest_pred-mean_Ytest_pred_vector)^2)+z*((mean(Ytest)-mean(Ytest_pred))^2)))^2
Output_list=list(CCC2_train=CCC2_train,r2_train=r2_train,RMSE_train=RMSE_train,k_train=k_train,k_prim_train=k_prim_train,r2_zero_train=r2_zero_train,r_prim2_zero_train=r_prim2_zero_train,r2_m_train=r2_m_train,r_prim2_m_train=r_prim2_m_train,r2_m_mean_train=r2_m_mean_train,delta_r2_m_train=delta_r2_m_train,r2_relative_1_train=r2_relative_1_train,r2_relative_2_train=r2_relative_2_train,delta_r2_zero_train=delta_r2_zero_train, MAE_train=MAE_train, CCC2_test=CCC2_test, r2_test=r2_test,RMSE_test=RMSE_test,k_test=k_test,k_prim_test=k_prim_test,r2_zero_test=r2_zero_test,r_prim2_zero_test=r_prim2_zero_test,r2_m_test=r2_m_test,r_prim2_m_test=r_prim2_m_test,r2_m_mean_test=r2_m_mean_test,delta_r2_m_test=delta_r2_m_test,r2_relative_1_test=r2_relative_1_test,r2_relative_2_test=r2_relative_2_test, delta_r2_zero_test=delta_r2_zero_test, MAE_test=MAE_test)
return(Output_list)
}
