# This program performs Y-randomization test on  Multiple Linear Regression (MLR) model.
# This program has been written by  Dr. Bakhtyar Sepehri.
# objects(molecules) must be in rows.
# repeat is the number of iteartion.
# Ytrain is dependent variable vector (a column vector).
# Xtrain is independent variable matrix (desciptor matrix for train set.).
# In Xtrain,molecules are in rows and descriptors are in columns.
# source code and type following commend in Console:
# YrandtestMLR(Ytrain,Xtrain,repeats)
YrandtestMLR=function(Ytrain,Xtrain,repeats){m=length(Ytrain)
Ytrain_new=matrix(rep(0),m,1)
R2train=matrix(rep(0),repeats,1)
ones_train=matrix(1,m,1)
Xtrain_new=cbind(ones_train,Xtrain)
for (j in 1:repeats){p=matrix(sample(m))
for (i in 1:m){Ytrain_new[i]=Ytrain[p[i]]
b=solve(t(Xtrain_new)%*%Xtrain_new)%*%t(Xtrain_new)%*%Ytrain_new
Ytrain_pred=Xtrain_new%*%b
Ytrain_bar=mean(Ytrain)*ones_train
W=Ytrain-Ytrain_bar
SST_train=t(W)%*%W
A=Ytrain_pred-Ytrain_bar
SRR_train=t(A)%*%A
SSE_train=SST_train-SRR_train
R2train[j]=SRR_train/SST_train}}
max_R2train=max(R2train)
Output_list=list(max_R2train=max_R2train)
return(Output_list)
}
